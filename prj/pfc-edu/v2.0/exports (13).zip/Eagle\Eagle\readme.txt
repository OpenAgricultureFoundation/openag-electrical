 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: D:\Export_Storage\ExportBase\0\269683\Output\Eagle\Eagle\Eagle.xml
 
 
To import your new library into Eagle:
1. Start Eagle.
2. In the control panel window, Select File -> New -> Library from the menu.
3. In the blank library window, select File -> Execute Script from the menu.
5. Browse to your newly exported Eagle Script file (".scr" file extension)
6. After opening the file, the script will populate the new library.
7. Use File -> Save (or Save As..) to save the library to the desired location in Eagle native format.


**************************************************************
**    !!!!!!!!!!!!!        WARNING        !!!!!!!!!!!!!     **
**************************************************************

Besure to check the documentation layer, "48"/"Document", for important information that may seem to be missing or have not translated properly!




For additional information, please visit this site:
http://www.accelerated-designs.com/help/Eagle_import.html

You may also find this video helpful:
http://youtu.be/5jGuWY-Yy3Q
 
 
The Symbol CONN_5-1634503-1_TYCO was missing a Value attribute, a value was created for the symbol.
The Symbol CONN_5-1634503-1_TYCO_2 was missing a Value attribute, a value was created for the symbol.
The Symbol CONN_5-1634503-1_TYCO_3 was missing a Value attribute, a value was created for the symbol.


Ultra Librarian Gold 8.2.234 Process Report



TextStyle count:  25
Padstack count:   2
Pattern count:    1
Symbol count:     3
Component count:  1

Export


