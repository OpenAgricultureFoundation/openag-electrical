 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: D:\Export_Storage\ExportBase\0\271661\Output\Eagle\Eagle\Eagle.xml
 
 
To import your new library into Eagle:
1. Start Eagle.
2. In the control panel window, Select File -> New -> Library from the menu.
3. In the blank library window, select File -> Execute Script from the menu.
5. Browse to your newly exported Eagle Script file (".scr" file extension)
6. After opening the file, the script will populate the new library.
7. Use File -> Save (or Save As..) to save the library to the desired location in Eagle native format.


**************************************************************
**    !!!!!!!!!!!!!        WARNING        !!!!!!!!!!!!!     **
**************************************************************

Besure to check the documentation layer, "48"/"Document", for important information that may seem to be missing or have not translated properly!




For additional information, please visit this site:
http://www.accelerated-designs.com/help/Eagle_import.html

You may also find this video helpful:
http://youtu.be/5jGuWY-Yy3Q
 
 


Ultra Librarian Gold 8.2.234 Process Report


Message - Padstack "RX46Y20D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX70Y24D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX58Y22D0T" Shape(4) is a CIRCLE with no diameter.

TextStyle count:  25
Padstack count:   3
Pattern count:    3
Symbol count:     1
Component count:  1

Export


